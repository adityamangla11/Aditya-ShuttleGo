from flask import render_template, request, redirect, url_for, session, flash, jsonify
from app import mysql
from . import passenger
import datetime

# Helper function to check if user is logged in as passenger
def passenger_login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'logged_in' not in session or session['user_type'] != 'passenger':
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated_function

@passenger.route('/home')
@passenger_login_required
def home():
    cursor = mysql.connection.cursor()
    
    # Fetch all buses for the feedback form
    cursor.execute("SELECT BusID, BusRegistrationNumber FROM Bus")
    buses = cursor.fetchall()
    
    cursor.close()
    
    return render_template('passenger/home.html', buses=buses)


@passenger.route('/view_schedule')
@passenger_login_required
def view_schedule():
    cursor = mysql.connection.cursor()
    
    # Get all schedules using the SQL query from first.sql
    cursor.execute("""
        SELECT s.JourneyID, s.DepartureDay, s.StartTime, s.EndTime, 
               r.StartLocation, r.EndLocation, b.BusRegistrationNumber, d.DriverName
        FROM Schedule s
        JOIN Route r ON s.RouteID = r.RouteID
        JOIN Bus b ON s.BusID = b.BusID
        JOIN Driver d ON s.DriverID = d.DriverID
        WHERE s.DepartureDay >= CURDATE()
        ORDER BY s.DepartureDay, s.StartTime, b.BusRegistrationNumber
    """)
    all_schedules = cursor.fetchall()
    
    # Get user's bookings
    cursor.execute("""
        SELECT b.JourneyID, b.BookingID, b.Seat
        FROM Bookings b
        WHERE b.UserID = %s
    """, [session['user_id']])
    bookings = cursor.fetchall()
    
    # Convert bookings to a dictionary for easier lookup
    user_bookings = {}
    for booking in bookings:
        user_bookings[booking['JourneyID']] = {
            'booking_id': booking['BookingID'],
            'seat': booking['Seat']
        }
    
    # Convert schedules to a dictionary
    schedules_dict = {}
    for schedule in all_schedules:
        journey_id = schedule['JourneyID']
        
        # Add booking status to the schedule
        schedule_with_status = dict(schedule)
        schedule_with_status['is_booked'] = journey_id in user_bookings
        if journey_id in user_bookings:
            schedule_with_status['booking_id'] = user_bookings[journey_id]['booking_id']
            schedule_with_status['seat'] = user_bookings[journey_id]['seat']
        
        # Group by date
        date_str = schedule['DepartureDay'].strftime('%Y-%m-%d')
        if date_str not in schedules_dict:
            schedules_dict[date_str] = []
        
        schedules_dict[date_str].append(schedule_with_status)
    
    # Convert back to a list, maintaining the sort order
    schedules_list = []
    for date in sorted(schedules_dict.keys()):
        for schedule in schedules_dict[date]:
            schedules_list.append(schedule)
    
    cursor.close()
    
    return render_template('passenger/schedule.html', schedules=schedules_list, user_bookings=user_bookings)

@passenger.route('/journey/<int:journey_id>')
@passenger_login_required
def journey(journey_id):
    cursor = mysql.connection.cursor()
    
    # Get journey details
    cursor.execute("""
        SELECT s.JourneyID, s.DepartureDay, s.StartTime, s.EndTime, 
               r.StartLocation, r.EndLocation, r.IntermediateLocations,
               b.BusRegistrationNumber, b.Capacity, d.DriverName
        FROM Schedule s
        JOIN Route r ON s.RouteID = r.RouteID
        JOIN Bus b ON s.BusID = b.BusID
        JOIN Driver d ON s.DriverID = d.DriverID
        WHERE s.JourneyID = %s
    """, [journey_id])
    journey = cursor.fetchone()
    
    if not journey:
        flash('Journey not found', 'danger')
        return redirect(url_for('passenger.view_schedule'))
    
    # Get all bookings for this journey
    cursor.execute("""
        SELECT b.BookingID, b.UserID, b.Seat, p.Name
        FROM Bookings b
        JOIN Passenger p ON b.UserID = p.PassengerID
        WHERE b.JourneyID = %s
    """, [journey_id])
    bookings = cursor.fetchall()
    
    # Create seat matrix
    seats = {}
    for i in range(1, journey['Capacity'] + 1):
        seats[i] = {'booked': False, 'user_id': None, 'name': None}
    
    for booking in bookings:
        seats[booking['Seat']] = {
            'booked': True,
            'user_id': booking['UserID'],
            'name': booking['Name'],
            'is_current_user': booking['UserID'] == session['user_id']
        }
    
    cursor.close()
    
    return render_template('passenger/journey.html', journey=journey, seats=seats)

@passenger.route('/book', methods=['POST'])
@passenger_login_required
def book():
    if request.method == 'POST':
        journey_id = request.form['journey_id']
        seat = request.form['seat']
        
        cursor = mysql.connection.cursor()
        
        # Use execute instead of callproc
        cursor.execute("CALL verify_new_booking(%s, %s, %s)", 
                      [journey_id, session['user_id'], seat])
        result = cursor.fetchone()
        
        # Get the first value regardless of the key
        valid = list(result.values())[0] if result else 0
        
        if valid == 1:
            cursor.execute("CALL create_new_booking(%s, %s, %s)", 
                         [journey_id, session['user_id'], seat])
            mysql.connection.commit()
            flash('Booking successful', 'success')
        else:
            flash('Booking failed. Seat may already be taken or journey is in the past.', 'danger')
        
        cursor.close()
        return redirect(url_for('passenger.view_schedule'))


@passenger.route('/cancel_booking', methods=['POST'])
@passenger_login_required
def cancel_booking():
    booking_id = request.form.get('booking_id')
    
    if not booking_id:
        flash('Invalid request', 'danger')
        return redirect(url_for('passenger.view_schedule'))
    cursor = mysql.connection.cursor()
    
    # Call the stored procedure to cancel the booking
    cursor.callproc('cancel_booking', [booking_id])
    
    # Fetch the result from the stored procedure
    result = cursor.fetchone()
    
    # Consume any remaining result sets
    while cursor.nextset():
        pass  # This is crucial to clear out any pending results
    
    # Now it's safe to commit
    mysql.connection.commit()
    
    cursor.close()
    
    if result and result['val']:
        flash('Booking cancelled successfully', 'success')
    else:
        flash('Cancellation not allowed within 3 hours of departure', 'danger')
    
    return redirect(url_for('passenger.view_schedule'))

@passenger.route('/generate_ticket', methods=['POST'])
@passenger_login_required
def generate_ticket():

    booking_id = request.form.get('booking_id')
    
    if not booking_id:
        flash('Invalid request', 'danger')
        return redirect(url_for('passenger.view_schedule'))
    
    cursor = mysql.connection.cursor()
    
    # Check if booking exists and belongs to user
    cursor.execute("""
        SELECT b.BookingID
        FROM Bookings b
        WHERE b.BookingID = %s AND b.UserID = %s
    """, (booking_id, session['user_id']))
    booking = cursor.fetchone()
    
    if not booking:
        flash('Booking not found', 'danger')
        return redirect(url_for('passenger.view_schedule'))
    
    # Generate new ticket using stored procedure
    cursor.callproc('GenerateTicket', [booking_id])
    
    # Fetch the result from the stored procedure
    ticket_info = cursor.fetchone()
    
    # Consume any remaining result sets
    while cursor.nextset():
        pass
    
    mysql.connection.commit()
    
    # Get the newly created ticket
    cursor.execute("SELECT * FROM Tickets WHERE BookingID = %s", [booking_id])
    ticket = cursor.fetchone()
    
    cursor.close()
    
    if not ticket:
        flash('Failed to generate ticket', 'danger')
        return redirect(url_for('passenger.view_schedule'))
    # return f"{existing_ticket}\n{ticket_info}"
    return render_template('passenger/ticket.html', ticket=ticket, ticket_info=ticket_info)


def can_cancel(departure_date, start_time):
    """Check if a booking can be canceled (more than 3 hours before departure)"""
    now = datetime.datetime.now()
    
    # Convert timedelta to time if needed
    if isinstance(start_time, datetime.timedelta):
        seconds = start_time.total_seconds()
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        seconds = int(seconds % 60)
        start_time = datetime.time(hours, minutes, seconds)
    
    departure = datetime.datetime.combine(departure_date, start_time)
    return (departure - now).total_seconds() > 10800  # 3 hours in seconds

@passenger.route('/booking_history')
@passenger_login_required
def booking_history():
    cursor = mysql.connection.cursor()
    
    # Execute the stored procedure using direct SQL execution
    cursor.execute("CALL GetUserBusUsage(%s)", [session['user_id']])
    
    # Fetch the results directly
    bookings = cursor.fetchall()
    
    # Get current date for comparison in template
    current_date = datetime.datetime.now().date()
    
    cursor.close()
    
    return render_template('passenger/booking_history.html', 
                          bookings=bookings, 
                          current_date=current_date,
                          can_cancel=can_cancel)

@passenger.route('/travel_history')
@passenger_login_required
def travel_history():
    cursor = mysql.connection.cursor()
    
    # Execute the GetUserBusUsage stored procedure
    cursor.execute("CALL GetUserBusUsage(%s)", [session['user_id']])
    
    # Fetch all travel records
    travels = cursor.fetchall()
    
    # Filter to only include journeys where the passenger actually boarded
    boarded_travels = [travel for travel in travels if travel['Boarded'] == 1]
    
    cursor.close()
    
    return render_template('passenger/travel_history.html', travels=boarded_travels)

@passenger.route('/penalties')
@passenger_login_required
def penalties():
    cursor = mysql.connection.cursor()
    cursor.execute("""
        SELECT p.PenaltyID, p.Reason, p.PenaltyAmount, p.PenaltyDate
        FROM Penalty p
        WHERE p.UserID = %s
        ORDER BY p.PenaltyDate DESC
    """, [session['user_id']])
    
    penalties = cursor.fetchall()
    
    # Add 'paid' attribute to each penalty
    for penalty in penalties:
        penalty['paid'] = penalty['PenaltyAmount'] == 0
    
    # Calculate totals
    unpaid_amount = sum(penalty['PenaltyAmount'] for penalty in penalties if not penalty['paid'])
    
    cursor.close()
    
    return render_template('passenger/penalties.html', 
                          penalties=penalties,
                          unpaid_amount=unpaid_amount)

@passenger.route('/profile', methods=['GET', 'POST'])
@passenger_login_required
def profile():
    cursor = mysql.connection.cursor()
    
    # Fetch current user data
    cursor.execute("SELECT * FROM Passenger WHERE PassengerID = %s", [session['user_id']])
    user = cursor.fetchone()
    
    if request.method == 'POST':
        # Handle form submission for profile updates
        name = request.form.get('name')
        dob = request.form.get('dob')
        mobile = request.form.get('mobile')
        
        # Handle image upload if provided
        if 'image' in request.files and request.files['image'].filename:
            image = request.files['image'].read()
            # Update with image
            cursor.execute("""
                UPDATE Passenger 
                SET Name = %s, DateOfBirth = %s, MobileNumber = %s, Image = %s
                WHERE PassengerID = %s
            """, (name, dob, mobile, image, session['user_id']))
        else:
            # Update without changing image
            cursor.execute("""
                UPDATE Passenger 
                SET Name = %s, DateOfBirth = %s, MobileNumber = %s
                WHERE PassengerID = %s
            """, (name, dob, mobile, session['user_id']))
        
        mysql.connection.commit()
        
        # Update session variables
        session['name'] = name
        
        flash('Profile updated successfully', 'success')
        
        # Fetch updated user data
        cursor.execute("SELECT * FROM Passenger WHERE PassengerID = %s", [session['user_id']])
        user = cursor.fetchone()
    
    cursor.close()
    
    return render_template('passenger/profile.html', user=user)

@passenger.route('/feedback', methods=['POST'])
@passenger_login_required
def submit_feedback():
    if request.method == 'POST':
        # Get form data
        bus_id = request.form.get('bus_id')
        rating = request.form.get('rating')
        feedback_text = request.form.get('feedback_text')
        
        # Validate input
        if not bus_id or not rating or not feedback_text:
            flash('Please provide a bus, rating, and feedback text', 'danger')
            return redirect(url_for('passenger.home'))
        
        try:
            bus_id = int(bus_id)
            rating = int(rating)
            if rating < 1 or rating > 5:
                raise ValueError("Rating must be between 1 and 5")
        except ValueError:
            flash('Invalid input values', 'danger')
            return redirect(url_for('passenger.home'))
        
        # Get current date
        current_date = datetime.datetime.now().date()
        
        cursor = mysql.connection.cursor()
        
        # Verify bus exists
        cursor.execute("SELECT BusID FROM Bus WHERE BusID = %s", [bus_id])
        bus = cursor.fetchone()
        
        if not bus:
            flash('Selected bus does not exist', 'danger')
            cursor.close()
            return redirect(url_for('passenger.home'))
        
        # Check if user has already provided feedback for this bus
        cursor.execute("""
            SELECT FeedbackID FROM Feedback 
            WHERE UserID = %s AND BusID = %s
        """, (session['user_id'], bus_id))
        existing_feedback = cursor.fetchone()
        
        if existing_feedback:
            # Update existing feedback
            cursor.execute("""
                UPDATE Feedback 
                SET FeedbackText = %s, Rating = %s, FeedbackDate = %s
                WHERE FeedbackID = %s
            """, (feedback_text, rating, current_date, existing_feedback['FeedbackID']))
            feedback_action = "updated"
        else:
            # Insert new feedback
            cursor.execute("""
                INSERT INTO Feedback (UserID, BusID, FeedbackText, Rating, FeedbackDate)
                VALUES (%s, %s, %s, %s, %s)
            """, (session['user_id'], bus_id, feedback_text, rating, current_date))
            feedback_action = "submitted"
        
        mysql.connection.commit()
        cursor.close()
        
        flash(f'Thank you! Your feedback has been {feedback_action}.', 'success')
        return redirect(url_for('passenger.home'))

@passenger.route('/payment_form/<int:penalty_id>')
@passenger_login_required
def payment_form(penalty_id):
    cursor = mysql.connection.cursor()
    
    # Verify the penalty belongs to the current user
    cursor.execute("""
        SELECT p.PenaltyID, p.UserID, p.PenaltyAmount, p.PenaltyDate, p.Reason
        FROM Penalty p
        WHERE p.PenaltyID = %s AND p.UserID = %s
    """, [penalty_id, session['user_id']])
    
    penalty = cursor.fetchone()
    cursor.close()
    
    if not penalty:
        flash('Penalty not found or does not belong to you', 'danger')
        return redirect(url_for('passenger.penalties'))
        
    if penalty['PenaltyAmount'] == 0:
        flash('This penalty has already been paid', 'info')
        return redirect(url_for('passenger.penalties'))
    
    return render_template('passenger/payment_form.html', penalty=penalty)

@passenger.route('/process_payment', methods=['POST'])
@passenger_login_required
def process_payment():
    if request.method == 'POST':
        penalty_id = request.form.get('penalty_id')
        payment_amount = float(request.form.get('payment_amount', 0))
        payment_method = request.form.get('payment_method')
        
        if not penalty_id or not payment_method:
            flash('Invalid payment information', 'danger')
            return redirect(url_for('passenger.penalties'))
            
        cursor = mysql.connection.cursor()
        
        # Verify the penalty belongs to the current user
        cursor.execute("""
            SELECT p.PenaltyID, p.UserID, p.PenaltyAmount 
            FROM Penalty p
            WHERE p.PenaltyID = %s AND p.UserID = %s
        """, [penalty_id, session['user_id']])
        
        penalty = cursor.fetchone()
        
        if not penalty:
            flash('Penalty not found or does not belong to you', 'danger')
            cursor.close()
            return redirect(url_for('passenger.penalties'))
            
        if penalty['PenaltyAmount'] == 0:
            flash('This penalty has already been paid', 'info')
            cursor.close()
            return redirect(url_for('passenger.penalties'))
        
        # Check if payment amount is valid
        if payment_amount <= 0:
            flash('Payment amount must be greater than zero', 'danger')
            cursor.close()
            return redirect(url_for('passenger.payment_form', penalty_id=penalty_id))
            
        # Check if payment amount is sufficient
        if payment_amount < penalty['PenaltyAmount']:
            # Partial payment
            new_amount = penalty['PenaltyAmount'] - payment_amount
            cursor.execute("""
                UPDATE Penalty
                SET PenaltyAmount = %s
                WHERE PenaltyID = %s
            """, [new_amount, penalty_id])
            mysql.connection.commit()
            flash(f'Partial payment of ₹{payment_amount} received. Remaining balance: ₹{new_amount}', 'info')
        else:
            # Full payment
            cursor.execute("""
                UPDATE Penalty
                SET PenaltyAmount = 0
                WHERE PenaltyID = %s
            """, [penalty_id])
            mysql.connection.commit()
            flash('Payment successful! Your penalty has been fully paid.', 'success')
            
        cursor.close()
        return redirect(url_for('passenger.penalties'))

@passenger.route('/pay_all_penalties')
@passenger_login_required
def pay_all_penalties():
    cursor = mysql.connection.cursor()
    
    # Get all unpaid penalties for the current user
    cursor.execute("""
        SELECT SUM(p.PenaltyAmount) as total_unpaid
        FROM Penalty p
        WHERE p.UserID = %s AND p.PenaltyAmount > 0
    """, [session['user_id']])
    
    result = cursor.fetchone()
    total_unpaid = result['total_unpaid'] if result and result['total_unpaid'] else 0
    
    cursor.close()
    
    if total_unpaid <= 0:
        flash('You have no unpaid penalties', 'info')
        return redirect(url_for('passenger.penalties'))
    
    # Redirect to a payment form for all penalties
    return render_template('passenger/pay_all_form.html', total_amount=total_unpaid)


@passenger.route('/process_all_payments', methods=['POST'])
@passenger_login_required
def process_all_payments():
    if request.method == 'POST':
        payment_amount = float(request.form.get('payment_amount', 0))
        payment_method = request.form.get('payment_method')
        
        if not payment_method or payment_amount <= 0:
            flash('Invalid payment information', 'danger')
            return redirect(url_for('passenger.penalties'))
            
        cursor = mysql.connection.cursor()
        
        # Get all unpaid penalties for the current user
        cursor.execute("""
            SELECT p.PenaltyID, p.PenaltyAmount
            FROM Penalty p
            WHERE p.UserID = %s AND p.PenaltyAmount > 0
            ORDER BY p.PenaltyDate ASC
        """, [session['user_id']])
        
        unpaid_penalties = cursor.fetchall()
        
        if not unpaid_penalties:
            flash('You have no unpaid penalties', 'info')
            cursor.close()
            return redirect(url_for('passenger.penalties'))
            
        # Calculate total unpaid amount
        total_unpaid = sum(penalty['PenaltyAmount'] for penalty in unpaid_penalties)
        
        # Check if payment amount is valid
        if payment_amount > total_unpaid:
            payment_amount = total_unpaid
        
        # Process payment for each penalty in order until payment amount is used up
        remaining_payment = payment_amount
        penalties_paid = 0
        
        for penalty in unpaid_penalties:
            if remaining_payment <= 0:
                break
                
            penalty_amount = penalty['PenaltyAmount']
            penalty_id = penalty['PenaltyID']
            
            if remaining_payment >= penalty_amount:
                # Full payment for this penalty
                cursor.execute("""
                    UPDATE Penalty
                    SET PenaltyAmount = 0
                    WHERE PenaltyID = %s
                """, [penalty_id])
                remaining_payment -= penalty_amount
                penalties_paid += 1
            else:
                # Partial payment for this penalty
                new_amount = penalty_amount - remaining_payment
                cursor.execute("""
                    UPDATE Penalty
                    SET PenaltyAmount = %s
                    WHERE PenaltyID = %s
                """, [new_amount, penalty_id])
                remaining_payment = 0
                penalties_paid += 1
        
        mysql.connection.commit()
        
        if penalties_paid == len(unpaid_penalties):
            flash(f'All penalties paid successfully! Total amount: ₹{payment_amount}', 'success')
        else:
            flash(f'Partial payment of ₹{payment_amount} applied to {penalties_paid} penalties', 'info')
            
        cursor.close()
        return redirect(url_for('passenger.penalties'))
