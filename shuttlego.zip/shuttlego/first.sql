-- file : first.sql

drop database if exists ShuttleGo;
create database ShuttleGo;
USE ShuttleGo;

SET GLOBAL event_scheduler = ON;


CREATE TABLE Passenger (
    PassengerID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(255) NOT NULL,
    Image BLOB DEFAULT NULL,
    DateOfBirth DATE DEFAULT NULL,
    IITGNEmail VARCHAR(255) NOT NULL UNIQUE,
    MobileNumber VARCHAR(10) DEFAULT NULL,
    check ((IITGNEmail like "%@iitgn.ac.in") and not (IITGNEmail like "% %"))
);
CREATE TABLE Bus (
    BusID INT PRIMARY KEY AUTO_INCREMENT,
    BusRegistrationNumber VARCHAR(11) NOT NULL UNIQUE,
    Capacity INT NOT NULL
);

-- add an attribute for image and one for password
CREATE TABLE Driver (
    DriverID INT PRIMARY KEY AUTO_INCREMENT,
    DriverName VARCHAR(255) NOT NULL,
    DriverMobileNumber VARCHAR(10) DEFAULT NULL,
    Image BLOB DEFAULT NULL,
    Password VARCHAR(255) NOT NULL DEFAULT "12345",
    check ((DriverMobileNumber is null) or (DriverMobileNumber rlike "[0-9]*" and length(DriverMobileNumber) = 10))
);
CREATE TABLE Route (
    RouteID INT PRIMARY KEY,
    StartLocation VARCHAR(255) NOT NULL,
    EndLocation VARCHAR(255) NOT NULL,
    StartLatitute FLOAT DEFAULT NULL,
    StartLongitude FLOAT DEFAULT NULL,
    EndLatitute FLOAT DEFAULT NULL,
    EndLongitude FLOAT DEFAULT NULL,
    IntermediateLocations VARCHAR(255)
);
CREATE TABLE Schedule (
    JourneyID INT PRIMARY KEY AUTO_INCREMENT,
    BusID INT,
    DriverID INT,
    RouteID INT,
    StartTime TIME NOT NULL,
    EndTime TIME NOT NULL,
    DepartureDay DATE NOT NULL,
    FOREIGN KEY (BusID) REFERENCES Bus(BusID),
    FOREIGN KEY (DriverID) REFERENCES Driver(DriverID),
    FOREIGN KEY (RouteID) REFERENCES Route(RouteID)
);
CREATE TABLE Bookings (
    BookingID INT PRIMARY KEY AUTO_INCREMENT,
    JourneyID INT NOT NULL,
    UserID INT NOT NULL,
    Seat INT NOT NULL,
    FOREIGN KEY (JourneyID) REFERENCES
    Schedule(JourneyID),
    FOREIGN KEY (UserID) REFERENCES
    Passenger(PassengerID)
);

CREATE TABLE Boarding (
    BookingID INT PRIMARY KEY,
    JourneyID INT NOT NULL,
    JourneyDate DATE NOT NULL,
    Boarded BOOLEAN,
    FOREIGN KEY (JourneyID) REFERENCES Schedule(JourneyID),
    FOREIGN KEY (BookingID) REFERENCES Bookings(BookingID)
);

CREATE TABLE LiveLocation (
    LocationID INT PRIMARY KEY AUTO_INCREMENT,
    BusID INT NOT NULL,
    Latitude FLOAT NOT NULL,
    Longitude FLOAT NOT NULL,
    LastUpdatedTime TIME,
    FOREIGN KEY (BusID) REFERENCES Bus(BusID)
);

CREATE TABLE Penalty (
    PenaltyID INT PRIMARY KEY AUTO_INCREMENT,
    UserID INT NOT NULL,
    Reason VARCHAR(255) NOT NULL,
    PenaltyAmount INT NOT NULL,
    PenaltyDate DATE,
    FOREIGN KEY (UserID) REFERENCES Passenger(PassengerID)
);
CREATE TABLE Authorities (
    AuthorityID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(255) NOT NULL,
    Email VARCHAR(255) NOT NULL UNIQUE,
    Password VARCHAR(255) NOT NULL
);
CREATE TABLE Feedback (
    FeedbackID INT PRIMARY KEY AUTO_INCREMENT,
    UserID INT NOT NULL,
    BusID INT NOT NULL,
    FeedbackText TEXT,
    Rating INT,
    FeedbackDate DATE NOT NULL,
    FOREIGN KEY (UserID) REFERENCES Passenger(PassengerID),
    FOREIGN KEY (BusID) REFERENCES Bus(BusID)
);

CREATE TABLE Tickets (
    TicketID VARCHAR(255) PRIMARY KEY,
    BookingID INT UNIQUE NOT NULL,
    DepartureDay DATE NOT NULL,
    StartTime TIME NOT NULL,
    EndTime TIME NOT NULL,
    SeatNumber INT NOT NULL,
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (BookingID) REFERENCES Bookings(BookingID) ON DELETE CASCADE
);

-- This is just a 1*1 table used as a variable.
CREATE TABLE ReturnCode (
    val BOOLEAN
);

INSERT INTO ReturnCode VALUES (true);

CREATE VIEW today as (SELECT DATE(NOW()));
CREATE VIEW rn as (SELECT NOW());
CREATE VIEW tommorrow as (select DATE(NOW()) + INTERVAL 1 DAY);
CREATE VIEW tommorrow_schedule as (SELECT * from Schedule where DepartureDay = (select * from tommorrow));

delimiter //

CREATE PROCEDURE last_30_days(IN usid INT)
BEGIN
SELECT * FROM Boarding WHERE BookingID IN (SELECT BookingID FROM Bookings WHERE usid = UserID and JourneyDate < DATE(NOW()) and JourneyDate > DATE(NOW()) - INTERVAL 30 DAY);
END //


CREATE PROCEDURE create_new_user(IN mid INT, IN nam VARCHAR(255), IN im BLOB, IN dob DATE, IN email VARCHAR(255), IN mob VARCHAR(10))
BEGIN
INSERT INTO Passenger (PassengerID, Name, Image, DateOfBirth, IITGNEmail, MobileNumber)
VALUES (mid, nam, im, dob, email, mob);
END //

CREATE PROCEDURE create_new_bus(IN brn VARCHAR(11), IN cap INT)
BEGIN
INSERT INTO Bus (BusRegistrationNumber, Capacity)
VALUES (brn, cap);
END //

CREATE PROCEDURE create_new_driver(IN nam VARCHAR(255),mob VARCHAR(10))
BEGIN
INSERT INTO Driver (DriverName, DriverMobileNumber)
VALUES (nam, mob);
END //

CREATE PROCEDURE create_new_route(IN rid INT, IN sl VARCHAR(255), IN el VARCHAR(255), IN intloc VARCHAR(255))
BEGIN
INSERT INTO Route (RouteID, StartLocation, EndLocation, IntermediateLocations)
VALUES (rid, sl, el, intloc);
END //


CREATE PROCEDURE create_new_schedule(IN bid INT, IN did INT, IN rid INT, IN st TIME, IN et TIME, IN dd DATE)
BEGIN
INSERT INTO Schedule (BusID, DriverID, RouteID, StartTime, EndTime, DepartureDay)
VALUES (bid, did, rid, st, et, dd);
END //


-- add a procedure to view schedule
-- add a precedure to view the seat matrix for a particular journey
-- journey id.

CREATE PROCEDURE create_new_booking(IN jid INT, IN usid INT, IN st INT)
-- create a new boarding item as well
BEGIN
INSERT INTO Bookings (JourneyID, UserID, Seat)
VALUES (jid, usid, st);

DECLARE new_booking_id INT;
SELECT LAST_INSERT_ID() INTO new_booking_id;

CALL create_new_boarding(new_booking_id);
END //

CREATE PROCEDURE cancel_booking(IN bid INT)
BEGIN
    DECLARE user_id INT;
    DECLARE journey_id INT;
    DECLARE departure_day DATE;
    DECLARE start_time TIME;
    DECLARE curr_time TIME;
    DECLARE curr_date DATE;

    -- Get current date and time
    SET curr_date = CURDATE();
    SET curr_time = CURTIME();

    -- Fetch booking details
    SELECT UserID, JourneyID 
    INTO user_id, journey_id
    FROM Bookings
    WHERE BookingID = bid;

    SELECT DepartureDay, StartTime 
    INTO departure_day, start_time
    FROM Schedule
    WHERE JourneyID = journey_id;

    -- Check if cancellation is within 1 hour of journey start time
    IF departure_day = curr_date AND start_time <= (curr_time + INTERVAL 1 HOUR) THEN
        -- Add a new penalty for late cancellation
        INSERT INTO Penalty (UserID, PenaltyAmount, PenaltyDate, Reason)
        VALUES (user_id, 20, curr_date, 'Late cancellation');
    END IF;

    -- Delete booking and related entries regardless of timing
    DELETE FROM Boarding WHERE BookingID = bid;
    DELETE FROM Tickets WHERE BookingID = bid;
    DELETE FROM Bookings WHERE BookingID = bid;

    -- Update ReturnCode to indicate success
    UPDATE ReturnCode SET val = TRUE;

    SELECT * FROM ReturnCode;
END //


-- Delete this in future
-- CREATE PROCEDURE verify_new_booking(IN jid INT, IN usid INT, IN st INT)
-- WITH 
-- journ as (SELECT * from Schedule where jid = JourneyID),
-- seated as (SELECT count(*) as val from Bookings where JourneyID = jid and (Seat = st or usid = UserID))
-- SELECT 1-count(*) from journ,seated where val > 0 or not (DepartureDay > DATE(NOW()) or StartTime > TIME(NOW()) + INTERVAL 3 HOUR);
-- END //

DELIMITER //

CREATE PROCEDURE verify_new_booking(IN jid INT, IN usid INT, IN st INT)
BEGIN
    WITH 
    journ AS (
        SELECT * 
        FROM Schedule 
        WHERE JourneyID = jid
    ),
    seated AS (
        SELECT COUNT(*) AS val 
        FROM Bookings 
        WHERE JourneyID = jid AND (Seat = st OR UserID = usid)
    ),
    penalty_check AS (
        SELECT COUNT(*) AS val 
        FROM Penalty 
        WHERE UserID = usid and PenaltyAmount > 0
    )
    SELECT 1 - COUNT(*) 
    FROM journ, seated, penalty_check 
    WHERE seated.val > 0 
       OR NOT (journ.DepartureDay > CURDATE() OR (journ.DepartureDay = CURDATE() AND journ.StartTime > CURTIME()))
       OR penalty_check.val > 3;
END //


-- delete this in future
-- CREATE PROCEDURE create_new_boarding(IN bid INT, IN seated BOOLEAN)
-- BEGIN
-- INSERT INTO Boarding (BookingID,JourneyID,JourneyDate,Boarded)
-- SELECT BookingID,Bookings.JourneyID,DepartureDay,seated FROM Bookings,Schedule WHERE BookingID = bid and Bookings.JourneyID = Schedule.JourneyID;
-- END//

CREATE PROCEDURE create_new_boarding(IN bid INT)
BEGIN
INSERT INTO Boarding (BookingID,JourneyID,JourneyDate,Boarded)
SELECT BookingID,Bookings.JourneyID,DepartureDay,FALSE FROM Bookings,Schedule 
WHERE BookingID = bid and Bookings.JourneyID = Schedule.JourneyID;
END //

CREATE PROCEDURE DeleteZeroPenalties()
BEGIN
    DELETE FROM Penalty
    WHERE PenaltyAmount = 0;
END //

CREATE EVENT IF NOT EXISTS DeleteZeroPenaltiesEvent
ON SCHEDULE EVERY 1 MONTH
STARTS LAST_DAY(CURRENT_DATE) + INTERVAL 1 SECOND
DO
    CALL DeleteZeroPenalties();
//

-- Create an event to run daily at 11:59 PM
CREATE EVENT IF NOT EXISTS daily_missed_bookings_check
ON SCHEDULE EVERY 1 DAY
STARTS CURRENT_DATE + INTERVAL 23 HOUR + INTERVAL 59 MINUTE
DO
    CALL CheckDailyMissedBookings();
//


CREATE PROCEDURE CheckDailyMissedBookings()
BEGIN
    -- Declare variables
    DECLARE today_date DATE;
    
    -- Get current date
    SET today_date = CURDATE();
    
    -- Find bookings that were scheduled for today but not boarded
    SELECT 
        b.BookingID,
        b.UserID,
        p.Name AS PassengerName,
        p.IITGNEmail AS PassengerEmail,
        s.JourneyID,
        s.StartTime,
        s.EndTime,
        r.StartLocation,
        r.EndLocation,
        bo.Boarded
    FROM 
        Bookings b
    JOIN 
        Passenger p ON b.UserID = p.PassengerID
    JOIN 
        Schedule s ON b.JourneyID = s.JourneyID
    JOIN 
        Route r ON s.RouteID = r.RouteID
    JOIN 
        Boarding bo ON b.BookingID = bo.BookingID
    WHERE 
        bo.JourneyDate = today_date
        AND (bo.Boarded = FALSE OR bo.Boarded IS NULL)
        AND s.EndTime < CURTIME(); -- Only include journeys that have already ended
    
    -- Add a new entry into the Penalty table for missed boardings
    INSERT INTO Penalty (UserID, PenaltyAmount, PenaltyDate, Reason)
    SELECT 
        b.UserID,
        20, -- Fixed penalty amount for missed boardings
        today_date,
        'Missed boarding without booking cancellation'
    FROM 
        Bookings b
    JOIN 
        Boarding bo ON b.BookingID = bo.BookingID
    JOIN 
        Schedule s ON b.JourneyID = s.JourneyID
    WHERE 
        bo.JourneyDate = today_date
        AND (bo.Boarded = FALSE OR bo.Boarded IS NULL)
        AND s.EndTime < CURTIME()
        AND NOT EXISTS (
            SELECT 1 FROM Penalty p 
            WHERE p.UserID = b.UserID 
            AND p.PenaltyDate = today_date
            AND p.Reason = 'Missed boarding without booking cancellation'
        );
END //


CREATE PROCEDURE GetLiveLocation(IN bus_id INT)
BEGIN
    SELECT Latitude, Longitude, LastUpdatedTime
    FROM LiveLocation
    WHERE BusID = bus_id
    ORDER BY LastUpdatedTime DESC
    LIMIT 1;
END //

CREATE PROCEDURE UpdateLiveLocation(IN bus_id INT, IN lat FLOAT, IN lon FLOAT)
BEGIN
    UPDATE LiveLocation
    SET Latitude = lat, Longitude = lon, LastUpdatedTime = NOW()
    WHERE BusID = bus_id;
END //


-- CREATE PROCEDURE GenerateTicket(IN bid INT) -- Generates a ticket, returns journey info to user, adds the ticket to the 'tickets' table for conductor to verify.
-- BEGIN
--     DECLARE ticketID VARCHAR(255);
--     DECLARE depDay DATE;
--     DECLARE st TIME;
--     DECLARE et TIME;
--     DECLARE seatNumber INT;
--     DECLARE startLoc VARCHAR(255);
--     DECLARE endLoc VARCHAR(255);

--     INTO depDay, st, et, seatNumber, startLoc, endLoc
--     SELECT s.DepartureDay, s.StartTime, s.EndTime, b.Seat, r.StartLocation, r.EndLocation
--     FROM Bookings b
--     JOIN Schedule s ON b.JourneyID = s.JourneyID
--     JOIN Route r ON s.RouteID = r.RouteID
--     WHERE b.BookingID = bid;

--     SET ticketID = CONCAT('TICKET-', bid, '-', UNIX_TIMESTAMP(NOW()));

--     INSERT INTO Tickets (TicketID, BookingID, DepartureDay, StartTime, EndTime, SeatNumber)
--     VALUES (ticketID, bid, depDay, st, et, seatNumber);

--     SELECT ticketID AS TicketIdentifier, depDay AS Departure_Date, st AS Start_Time, et AS End_Time, 
--            seatNumber AS Seat_Number, startLoc AS Start_Location, endLoc AS End_Location;
-- END //

CREATE PROCEDURE GenerateTicket(IN bid INT) 
BEGIN
    DECLARE ticketID VARCHAR(255);
    DECLARE depDay DATE;
    DECLARE st TIME;
    DECLARE et TIME;
    DECLARE seatNumber INT;
    DECLARE startLoc VARCHAR(255);
    DECLARE endLoc VARCHAR(255);

    SELECT s.DepartureDay, s.StartTime, s.EndTime, b.Seat, r.StartLocation, r.EndLocation
    INTO depDay, st, et, seatNumber, startLoc, endLoc
    FROM Bookings b
    JOIN Schedule s ON b.JourneyID = s.JourneyID
    JOIN Route r ON s.RouteID = r.RouteID
    WHERE b.BookingID = bid;

    SET ticketID = CONCAT('TICKET-', bid, '-', UNIX_TIMESTAMP(NOW()));

    INSERT IGNORE INTO Tickets (TicketID, BookingID, DepartureDay, StartTime, EndTime, SeatNumber)
    VALUES (ticketID, bid, depDay, st, et, seatNumber);

    SELECT ticketID AS TicketIdentifier, depDay AS Departure_Date, st AS Start_Time, et AS End_Time, 
            seatNumber AS Seat_Number, startLoc AS Start_Location, endLoc AS End_Location;
END //

CREATE PROCEDURE VerifyTicket(IN ticketID VARCHAR(255))
BEGIN
    DECLARE depDay DATE;
    DECLARE st TIME;
    DECLARE et TIME;
    DECLARE seatNumber INT;
    DECLARE startLoc VARCHAR(255);
    DECLARE endLoc VARCHAR(255);
    DECLARE bookingID INT;
    DECLARE journeyID INT;
    DECLARE isValid BOOLEAN DEFAULT FALSE;

    SELECT t.DepartureDay, t.StartTime, t.EndTime, t.SeatNumber, 
           r.StartLocation, r.EndLocation, t.BookingID, b.JourneyID
    INTO depDay, st, et, seatNumber, startLoc, endLoc, bookingID, journeyID
    FROM Tickets t
    JOIN Bookings b ON t.BookingID = b.BookingID
    JOIN Schedule s ON b.JourneyID = s.JourneyID
    JOIN Route r ON s.RouteID = r.RouteID
    WHERE t.TicketID = ticketID;

    IF depDay = CURDATE() AND et > CURTIME() THEN
        -- ✅ Mark as boarded instead of inserting
        UPDATE Boarding
        SET Boarded = TRUE
        WHERE BookingID = bookingID AND JourneyID = journeyID AND JourneyDate = depDay;

        SELECT 'Valid' AS Status, ticketID AS TicketIdentifier, depDay AS Date, 
               st AS Start_Time, et AS End_Time, seatNumber AS Seat_Number, 
               startLoc AS Start_Location, endLoc AS End_Location;
    ELSEIF depDay < CURDATE() THEN
        SELECT 'Expired' AS Status;
    ELSEIF depDay > CURDATE() THEN
        SELECT 'Shuttle not Departing Today' AS Status;
    ELSEIF et <= CURTIME() THEN
        SELECT 'Journey already finished' AS Status;
    ELSEIF st <= CURTIME() THEN
        SELECT 'Shuttle has already departed' AS Status;
    ELSE
        SELECT 'Invalid' AS Status;
    END IF;
END //

CREATE PROCEDURE GetUserBusUsage(IN usid INT)
BEGIN
    SELECT 
        B.BookingID,
        S.DepartureDay,
        S.StartTime,
        S.EndTime,
        R.StartLocation,
        R.EndLocation,
        Bus.BusRegistrationNumber,
        D.DriverName,
        B.Seat,
        Brd.Boarded
    FROM Bookings B
    JOIN Schedule S ON B.JourneyID = S.JourneyID
    JOIN Route R ON S.RouteID = R.RouteID
    JOIN Bus ON S.BusID = Bus.BusID
    JOIN Driver D ON S.DriverID = D.DriverID
    LEFT JOIN Boarding Brd ON B.BookingID = Brd.BookingID
    WHERE B.UserID = usid
    AND S.DepartureDay >= DATE(NOW()) - INTERVAL 30 DAY;
END //

CREATE PROCEDURE GetBusUsageByBus(IN busid INT)
BEGIN
    SELECT 
        S.JourneyID,
        S.DepartureDay,
        S.StartTime,
        S.EndTime,
        R.StartLocation,
        R.EndLocation,
        COUNT(B.BookingID) AS SeatsBooked  -- Counting booked seats per journey
    FROM Schedule S
    JOIN Route R ON S.RouteID = R.RouteID
    LEFT JOIN Bookings B ON S.JourneyID = B.JourneyID
    WHERE S.BusID = busid
    AND S.DepartureDay >= DATE(NOW()) - INTERVAL 30 DAY
    GROUP BY S.JourneyID, S.DepartureDay, S.StartTime, S.EndTime, R.StartLocation, R.EndLocation;
END //

delimiter ;